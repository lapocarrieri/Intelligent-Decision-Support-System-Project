// function showList(e) {
//     var $gridCont = $('.grid-container');
//     e.preventDefault();
//     $gridCont.hasClass('list-view') ? $gridCont.removeClass('list-view') : $gridCont.addClass('list-view');
//     console.log("showing list");
//   }
//   function gridList(e) {
//     var $gridCont = $('.grid-container')
//     e.preventDefault();
//     $gridCont.removeClass('list-view');
//     console.log("showing grid");
//   }
  
//   $(document).on('click', '.btn-grid', gridList);
//   $(document).on('click', '.btn-list', showList)