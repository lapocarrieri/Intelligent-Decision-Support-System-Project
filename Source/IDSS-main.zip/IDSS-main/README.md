# IDSS
set up you virtual environnement : 
'python -m venv venv'
'./venv/Script/activate'

Upgrade the environnement
'python -m pip install --upgrade pip'
'python -m pip install -r /path/to/requirements.txt'

Before running the app, launch these 2 commands, then run : 
'python -m flask run'
